package com.cg.client;

import com.cg.application.MMBankFactory;
import com.cg.application.MMCurrentAcc;
import com.cg.application.MMSavingAcc;
import com.cg.framework.BankFactory;
import com.cg.framework.CurrentAcc;
import com.cg.framework.SavingAcc;

public class Client {

	public static void main(String[] args) {
		BankFactory mbf =new MMBankFactory();
		SavingAcc sa=new MMSavingAcc(3456,"saran",2000.0f,true);
		sa.withdraw(sa.getAccBal());
		sa.toString();
		CurrentAcc ca=new MMCurrentAcc(3457,"sari",10000.0f,5000.0f);
		ca.withdraw(ca.getCreditLimit());
		ca.toString();
		

	}

}
